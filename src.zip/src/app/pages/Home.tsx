import { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence, useInView, useScroll, useTransform } from "motion/react";
import { Helmet } from "react-helmet";
import { useNavigate } from "react-router";

const WHATSAPP_URL = "https://wa.me/917218344700?text=Hi%20ARCHORA%2C%20I%20am%20interested%20in%20discussing%20a%20healthcare%20infrastructure%20project.";

const FONT = "Calibri, Arial, sans-serif";

// ─────────────────────────────────────────────
// DESIGN TOKENS
// ─────────────────────────────────────────────
const C = {
  navy:    "#041c2e",
  navyMid: "#0a2e47",
  blue:    "#1b6ca8",
  teal:    "#4bccd4",
  cream:   "#f5f1eb",
  creamAlt:"#ede9e1",
  red:     "#c0392b",
  white:   "#ffffff",
};

// ─────────────────────────────────────────────
// SEO COMPONENT
// ─────────────────────────────────────────────
function SEOHead() {
  const schemaOrg = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": "https://archora.in/#organization",
        "name": "ARCHORA",
        "url": "https://archora.in",
        "logo": "https://archora.in/logo.png",
        "description": "India's dedicated healthcare infrastructure partner, hospital design, construction, modular OT & ICU, NABH-compliant architecture, and turnkey delivery across India.",
        "areaServed": "IN",
        "knowsAbout": [
          "Hospital Architecture",
          "Healthcare Infrastructure",
          "NABH Compliance",
          "Modular OT Design",
          "ICU Infrastructure",
          "Medical Equipment Planning",
          "Hospital Construction",
          "MEP Engineering"
        ],
        "sameAs": []
      },
      {
        "@type": "WebSite",
        "@id": "https://archora.in/#website",
        "url": "https://archora.in",
        "name": "ARCHORA, Healthcare Architecture Partner",
        "publisher": { "@id": "https://archora.in/#organization" }
      },
      {
        "@type": "WebPage",
        "@id": "https://archora.in/#webpage",
        "url": "https://archora.in",
        "name": "ARCHORA, Healthcare Architecture Partner",
        "description": "ARCHORA is a healthcare architecture firm designing NABH-compliant hospitals, clinics, OTs, ICUs, and labs across India, from planning to installation.",
        "isPartOf": { "@id": "https://archora.in/#website" },
        "about": { "@id": "https://archora.in/#organization" },
        "breadcrumb": {
          "@type": "BreadcrumbList",
          "itemListElement": [{ "@type": "ListItem", "position": 1, "name": "Home", "item": "https://archora.in" }]
        }
      },
      {
        "@type": "LocalBusiness",
        "@id": "https://archora.in/#localbusiness",
        "name": "ARCHORA Healthcare Infrastructure",
        "description": "Full-service healthcare infrastructure firm, hospital architecture, MEP engineering, modular OT & ICU, NABH compliance, turnkey delivery across India.",
        "url": "https://archora.in",
        "priceRange": "₹₹₹",
        "areaServed": [
          { "@type": "Country", "name": "India" }
        ],
        "serviceType": [
          "Hospital Design and Architecture",
          "Healthcare Construction",
          "Modular OT Infrastructure",
          "ICU Design",
          "NABH Compliance Consulting",
          "Medical Equipment Planning",
          "MEP Engineering for Healthcare",
          "Hospital Project Management"
        ]
      }
    ]
  };

  return (
    <Helmet>
      {/* Primary Meta */}
      <title>ARCHORA, Healthcare Architecture Partner</title>
      <meta name="description" content="ARCHORA is a healthcare architecture firm designing NABH-compliant hospitals, clinics, OTs, ICUs, and labs across India, from planning to installation." />
      <meta name="keywords" content="hospital design India, healthcare infrastructure, NABH compliant hospital, modular OT design, hospital construction India, ICU infrastructure, medical college design, turnkey hospital, hospital architecture India, MEP engineering healthcare" />
      <link rel="canonical" href="https://archora.in" />

      {/* Open Graph */}
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://archora.in" />
      <meta property="og:title" content="ARCHORA, Healthcare Architecture Partner" />
      <meta property="og:description" content="ARCHORA is a healthcare architecture firm designing NABH-compliant hospitals, clinics, OTs, ICUs, and labs across India, from planning to installation." />
      <meta property="og:image" content="https://archora.in/og-image.jpg" />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:locale" content="en_IN" />
      <meta property="og:site_name" content="ARCHORA" />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content="ARCHORA, Healthcare Architecture Partner" />
      <meta name="twitter:description" content="ARCHORA is a healthcare architecture firm designing NABH-compliant hospitals, clinics, OTs, ICUs, and labs across India, from planning to installation." />
      <meta name="twitter:image" content="https://archora.in/og-image.jpg" />

      {/* Geo & Language */}
      <meta name="geo.region" content="IN" />
      <meta name="geo.placename" content="India" />
      <meta name="language" content="English" />
      <meta httpEquiv="content-language" content="en-IN" />

      {/* Robots */}
      <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />

      {/* Schema.org JSON-LD */}
      <script type="application/ld+json">{JSON.stringify(schemaOrg)}</script>
    </Helmet>
  );
}

// ─────────────────────────────────────────────
// SHARED SVG DECORATIONS
// ─────────────────────────────────────────────
function MedicalCross({ size = 20, color = C.red, opacity = 0.85 }: { size?: number; color?: string; opacity?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="6.5" y="1" width="7" height="18" rx="1.5" fill={color} opacity={opacity} />
      <rect x="1" y="6.5" width="18" height="7" rx="1.5" fill={color} opacity={opacity} />
    </svg>
  );
}

function AnimatedCounter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  useEffect(() => {
    if (!inView) return;
    let raf: number;
    const start = performance.now();
    const duration = 1800;
    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1);
      const ease = 1 - Math.pow(1 - t, 3);
      setCount(Math.floor(ease * to));
      if (t < 1) raf = requestAnimationFrame(tick);
      else setCount(to);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to]);
  return <span ref={ref}>{count}{suffix}</span>;
}

// ─────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────
const heroSlides = [
  {
    src: "/images/projects/gallery/binar-mp-03.png",
    label: "01, Architecture",
    tag: "India's Dedicated Partner",
    headline: "India's Dedicated Healthcare Infrastructure Partner",
    sub: "We design, build, and deliver hospitals, clinics, modular OTs, ICUs, laboratories, and medical colleges across India, under one roof.",
  },
  {
    src: "/images/hero/hero-slide-2.jpg",
    label: "02, Compliance",
    tag: "NABH From Day One",
    headline: "NABH-Compliant Design. From Day One.",
    sub: "No retrofitting. No last-minute corrections. Every standard integrated from the very first drawing.",
  },
  {
    src: "/images/hero/hero-slide-3.jpg",
    label: "03, Delivery",
    tag: "Single Accountability",
    headline: "One Team. One Contract. Full Accountability.",
    sub: "From concept to commissioning, ARCHORA takes complete responsibility so you don't manage 15 vendors alone.",
  },
  {
    src: "/images/projects/gallery/binar-mp-06.png",
    label: "04, Innovation",
    tag: "Global Standards",
    headline: "Global Standards. International Delivery.",
    sub: "NHS-level healthcare infrastructure expertise meets India-specific clinical realities, in every project we deliver.",
  },
];

const services = [
  { num: "01", slug: "feasibility-studies", title: "Feasibility Studies & DPRs", desc: "Data-backed project planning before you commit capital. Site assessment, demand analysis, bed capacity planning, and cost estimation." },
  { num: "02", slug: "healthcare-architecture", title: "Healthcare Architecture & Space Planning", desc: "Compliance-integrated architectural design for hospitals, clinics, diagnostic centres, and medical colleges." },
  { num: "03", slug: "regulatory-compliance", title: "Regulatory Compliance & Accreditation-Ready Design", desc: "NABH, NABL, INC, NMC, AERB, PCPNDT, NBC, and fire safety standards integrated into every design from day one." },
  { num: "04", slug: "hospital-licensing", title: "Hospital Licensing & Approvals Support", desc: "Expert navigation of all statutory licences and approvals required to open and operate a healthcare facility in India." },
  { num: "05", slug: "structural-design", title: "Structural Design for Healthcare", desc: "Healthcare-specific structural engineering for heavy equipment loads, seismic compliance, and clinical environments." },
  { num: "06", slug: "mep-engineering", title: "MEP Engineering for Healthcare", desc: "Hospital-grade HVAC, medical gas pipeline systems, electrical, plumbing, fire safety, and building management." },
  { num: "07", slug: "modular-ot-icu", title: "Modular OT & ICU Infrastructure", desc: "Design, supply, and installation of modular operating theatres and ICUs with laminar airflow and cleanroom standards." },
  { num: "08", slug:  "turnkey-execution", title: "Turnkey Civil & Interior Execution", desc: "Complete healthcare construction and interior fit-out through a single point of accountability." },
  { num: "09", slug: "medical-equipment-planning", title: "Medical Equipment Planning & Procurement", desc: "Department-wise planning, budget optimisation, vendor evaluation, procurement support, and installation coordination." },
  { num: "10", slug: "project-management", title: "Project Management & Commissioning", desc: "End-to-end project management from planning through to commissioning and handover: protecting your timeline." },
];

const metrics = [
  { val: 20, suffix: "+", label: "Years Collective Experience" },
  { val: 100, suffix: "%", label: "Healthcare Projects Only" },
  { val: 10, suffix: "", label: "Core Service Disciplines" },
  { val: 35, suffix: "+", label: "Facility Type Specialisations" },
];

// ─────────────────────────────────────────────
// ANIMATION PRESETS
// ─────────────────────────────────────────────
const fadeUp = {
  initial: { opacity: 0, y: 48 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" } as const,
  transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] as const },
};

// ─────────────────────────────────────────────
// SECTION LABEL
// ─────────────────────────────────────────────
function SectionLabel({ text, light = false }: { text: string; light?: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
      <span style={{ width: 28, height: 1, background: light ? "rgba(75,204,212,0.6)" : C.blue, display: "block" }} />
      <span style={{
        fontFamily: FONT,
        fontSize: 39,
        letterSpacing: "0.28em",
        textTransform: "uppercase",
        color: light ? "rgba(75,204,212,0.7)" : C.blue,
      }}>{text}</span>
    </div>
  );
}

// ─────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────
export function Home() {
  const navigate = useNavigate();
  const [heroIndex, setHeroIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goTo = useCallback((idx: number, dir: number) => {
    setDirection(dir);
    setHeroIndex(idx);
  }, []);
  const next = useCallback(() => goTo((heroIndex + 1) % heroSlides.length, 1), [heroIndex, goTo]);
  const prev = useCallback(() => goTo((heroIndex - 1 + heroSlides.length) % heroSlides.length, -1), [heroIndex, goTo]);

  useEffect(() => {
    timerRef.current = setInterval(next, 7000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [next]);

  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress: heroScroll } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(heroScroll, [0, 1], ["0%", "20%"]);

  return (
    <>
      <SEOHead />

      <div style={{ fontFamily: FONT, overflowX: "hidden", background: C.cream }}>
        <style>{`
          @keyframes spinCW { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
          @keyframes spinCCW { from { transform: rotate(0deg); } to { transform: rotate(-360deg); } }

          /* ============ RESPONSIVE LAYOUT RULES ============ */

          /* Section wrappers: fixed 80px side padding crushed mobile content.
             Scale padding down at tablet and phone widths. */
          .home-wrap {
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 80px;
            box-sizing: border-box;
          }
          @media (max-width: 1024px) {
            .home-wrap { padding: 0 48px; }
          }
          @media (max-width: 640px) {
            .home-wrap { padding: 0 24px; }
          }

          /* Two-column split sections (Problem, Who We Are): stack on tablet/phone */
          .home-split-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 100px;
            align-items: center;
          }
          @media (max-width: 900px) {
            .home-split-2 {
              grid-template-columns: 1fr;
              gap: 56px;
            }
          }

          /* 3-column mini-stat row inside Who We Are */
          .home-stat-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 28px;
          }
          @media (max-width: 520px) {
            .home-stat-3 {
              grid-template-columns: 1fr;
              gap: 20px;
            }
          }

          /* Metrics strip: 4 columns -> 2 -> 1 */
          .home-metrics-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
          }
          @media (max-width: 760px) {
            .home-metrics-grid {
              grid-template-columns: repeat(2, 1fr);
              row-gap: 36px;
            }
          }
          @media (max-width: 420px) {
            .home-metrics-grid {
              grid-template-columns: 1fr;
            }
          }
          .home-metric-cell {
            text-align: center;
            padding: 0 32px;
          }
          @media (max-width: 760px) {
            .home-metric-cell { padding: 0 12px; }
          }
          .home-metric-cell.has-border {
            border-right: 1px solid rgba(255,255,255,0.18);
          }
          @media (max-width: 760px) {
            .home-metric-cell.has-border { border-right: none; }
          }

          /* Services grid: 2 columns -> 1 on mobile */
          .home-services-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1px;
            background: rgba(75,204,212,0.06);
          }
          @media (max-width: 760px) {
            .home-services-grid {
              grid-template-columns: 1fr;
            }
          }

          /* Hero content area: free-floating absolute nav dots / slide label
             collide with heading text on narrow screens, so hide/reflow them. */
          .home-hero-side-dots {
            position: absolute;
            left: 32px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            z-index: 20;
          }
          @media (max-width: 760px) {
            .home-hero-side-dots { display: none; }
          }

          .home-hero-slide-label {
            position: absolute;
            top: 88px;
            right: 32px;
            z-index: 20;
          }
          @media (max-width: 760px) {
            .home-hero-slide-label { top: 20px; right: 16px; }
          }
          @media (max-width: 480px) {
            .home-hero-slide-label { display: none; }
          }

          .home-hero-content {
            position: relative;
            height: 100%;
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 80px;
            display: flex;
            align-items: center;
            z-index: 10;
            box-sizing: border-box;
          }
          @media (max-width: 1024px) {
            .home-hero-content { padding: 0 48px; }
          }
          @media (max-width: 640px) {
            .home-hero-content { padding: 0 24px; }
          }

          .home-hero-inner {
            max-width: 680px;
          }

          .home-hero-headline {
            font-size: clamp(2.1rem, 7vw, 4.4rem);
          }

          /* About image frame: decorative offset border + corner brackets add
             extra box dimensions beyond the image — contain them on mobile. */
          .home-about-frame {
            position: relative;
          }
          .home-about-offset-border {
            position: absolute;
            top: -16px;
            left: -16px;
            right: 16px;
            bottom: 16px;
            border: 1px solid rgba(27,108,168,0.2);
          }
          @media (max-width: 640px) {
            .home-about-offset-border { top: -8px; left: -8px; right: 8px; bottom: 8px; }
          }
          .home-about-img {
            width: 100%;
            height: 500px;
            object-fit: cover;
            display: block;
          }
          @media (max-width: 760px) {
            .home-about-img { height: 360px; }
          }
          @media (max-width: 480px) {
            .home-about-img { height: 280px; }
          }

          /* Bottom carousel controls: tighten on phone so arrows don't crowd dots */
          .home-carousel-controls {
            position: absolute;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 20;
            max-width: calc(100% - 32px);
          }
          @media (max-width: 480px) {
            .home-carousel-controls { gap: 8px; bottom: 16px; }
          }
        `}</style>

        {/* ══════════════════════════════════════════
            HERO, IMMERSIVE CAROUSEL
        ══════════════════════════════════════════ */}
        <section ref={heroRef} aria-label="Hero" style={{ position: "relative", height: "100vh", minHeight: 560, overflow: "hidden" }}>

          <AnimatePresence initial={false} custom={direction} mode="sync">
            <motion.div
              key={heroIndex}
              custom={direction}
              initial={{ opacity: 0, scale: 1.06 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
              style={{ position: "absolute", inset: 0 }}
            >
              <motion.div style={{ position: "absolute", inset: 0, y: heroY }}>
                <img
                  src={heroSlides[heroIndex].src}
                  alt={heroSlides[heroIndex].headline}
                  style={{ width: "100%", height: "110%", objectFit: "cover", objectPosition: "center" }}
                  fetchPriority="high"
                />
              </motion.div>
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(110deg, rgba(4,28,46,0.6) 0%, rgba(4,28,46,0.34) 50%, rgba(4,28,46,0.08) 100%)" }} />
              <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(4,28,46,0.38) 0%, transparent 45%)" }} />
            </motion.div>
          </AnimatePresence>

          {/* Left nav dots — hidden on mobile, see .home-hero-side-dots */}
          <div className="home-hero-side-dots">
            <div style={{ width: 1, height: 80, background: "rgba(255,255,255,0.12)" }} />
            {heroSlides.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i, i > heroIndex ? 1 : -1)}
                aria-label={`Go to slide ${i + 1}`}
                style={{
                  width: 6, height: 6, borderRadius: "50%", border: "none", cursor: "pointer", padding: 0,
                  background: i === heroIndex ? C.teal : "rgba(255,255,255,0.25)",
                  transform: i === heroIndex ? "scale(1.5)" : "scale(1)",
                  transition: "all 0.3s",
                }}
              />
            ))}
            <div style={{ width: 1, height: 80, background: "rgba(255,255,255,0.12)" }} />
          </div>

          {/* Main hero content */}
          <div className="home-hero-content">
            <div className="home-hero-inner">
              <motion.div
                style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 32 }}
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
              >
                <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 14, fontFamily: FONT }}>0{heroIndex + 1}</span>
                <div style={{ position: "relative", height: 1, width: 60, background: "rgba(255,255,255,0.15)", overflow: "hidden" }}>
                  <motion.div
                    key={heroIndex}
                    style={{ position: "absolute", inset: 0, background: C.teal, transformOrigin: "left" }}
                    initial={{ scaleX: 0 }} animate={{ scaleX: 1 }}
                    transition={{ duration: 7, ease: "linear" }}
                  />
                </div>
                <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 14, fontFamily: FONT }}>0{heroSlides.length}</span>
              </motion.div>

              <motion.div
                style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}
                initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <span style={{ color: "rgba(255,255,255,0.90)", fontSize: 13, fontWeight: 700, letterSpacing: "0.28em", textTransform: "uppercase", fontFamily: FONT }}>
                  Healthcare Infrastructure Partner
                </span>
              </motion.div>

              <AnimatePresence mode="wait">
                <motion.h1
                  key={heroIndex}
                  className="home-hero-headline"
                  initial={{ opacity: 0, y: 36, clipPath: "inset(100% 0 0 0)" }}
                  animate={{ opacity: 1, y: 0, clipPath: "inset(0% 0 0 0)" }}
                  exit={{ opacity: 0, y: -24 }}
                  transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
                  style={{
                    color: C.white,
                    marginBottom: 24, lineHeight: 1.1,
                    fontFamily: FONT, fontWeight: 600,
                    letterSpacing: "-0.01em",
                  }}
                >
                  {heroSlides[heroIndex].headline}
                </motion.h1>
              </AnimatePresence>

              <motion.p
                key={`sub-${heroIndex}`}
                style={{ fontSize: 16, color: "#ffffff", marginBottom: 36, lineHeight: 1.75, maxWidth: 520, fontFamily: FONT, fontWeight: 400 }}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.4 }}
              >
                {heroSlides[heroIndex].sub}
              </motion.p>

              <motion.div
                style={{ display: "flex", gap: 14, flexWrap: "wrap" }}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, delay: 0.58 }}
              >
                <HeroBtn primary onClick={() => navigate("/contact")}>Book a Free Consultation</HeroBtn>
                <HeroBtn onClick={() => navigate("/services")}>Explore Our Services</HeroBtn>
              </motion.div>

              <motion.p
                style={{ marginTop: 20, fontSize: 12, color: "rgba(255,255,255,0.25)", letterSpacing: "0.1em", fontFamily: FONT }}
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }}
              >
                No obligation · No sales pressure · Honest expert advice
              </motion.p>
            </div>
          </div>

          {/* Bottom carousel controls */}
          <div className="home-carousel-controls">
            <NavBtn onClick={prev} aria-label="Previous slide">‹</NavBtn>
            <div style={{ display: "flex", gap: 6 }} role="tablist" aria-label="Slide navigation">
              {heroSlides.map((_, i) => (
                <button
                  key={i}
                  role="tab"
                  aria-selected={i === heroIndex}
                  aria-label={`Slide ${i + 1}`}
                  onClick={() => goTo(i, i > heroIndex ? 1 : -1)}
                  style={{
                    height: 2, border: "none", cursor: "pointer", padding: 0,
                    width: i === heroIndex ? 44 : 18,
                    background: i === heroIndex ? C.teal : "rgba(255,255,255,0.2)",
                    transition: "all 0.3s ease",
                  }}
                />
              ))}
            </div>
            <NavBtn onClick={next} aria-label="Next slide">›</NavBtn>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            MARQUEE TICKER
        ══════════════════════════════════════════ */}
        <div
          aria-hidden="true"
          style={{ background: C.navy, padding: "13px 0", overflow: "hidden", borderBottom: `1px solid rgba(75,204,212,0.12)`, position: "relative" }}
        >
          <motion.div
            style={{ display: "flex", gap: 0, whiteSpace: "nowrap" }}
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
          >
            {Array(6).fill(["Hospital Planning", "Modular OT Design", "ICU Infrastructure", "NABH Compliance", "MEP Engineering", "Turnkey Delivery", "Medical Equipment Planning", "International Projects"]).flat().map((item, i) => (
              <span key={i} style={{
                color: "rgba(75,204,212,0.45)", fontSize: 13, letterSpacing: "0.26em",
                textTransform: "uppercase", fontFamily: FONT,
                paddingRight: 48, display: "inline-flex", alignItems: "center", gap: 48,
              }}>
                {item}
                <span style={{ color: "rgba(75,204,212,0.18)", fontSize: 11 }}>◆</span>
              </span>
            ))}
          </motion.div>
        </div>

        {/* ══════════════════════════════════════════
            PROBLEM SECTION
        ══════════════════════════════════════════ */}
        <section aria-labelledby="problem-heading" style={{ background: C.navy, padding: "80px 0", position: "relative", overflow: "hidden" }}>
          <div className="home-wrap">
            <div className="home-split-2">

              <motion.div {...fadeUp}>
                <SectionLabel text="The Problem We Solve" light  />
                <h2 id="problem-heading" style={{ color: C.white, fontSize: "clamp(1.9rem, 5vw, 3.4rem)", lineHeight: 1.18, marginBottom: 28, fontWeight: 400, fontFamily: FONT }}>
                  Most Healthcare Facilities in India Are Built by the Wrong Team
                </h2>

                {[
                  "Building a hospital is not the same as building a commercial space. Clinical workflows, infection control, regulatory compliance, patient safety, and 24×7 operational demands make healthcare construction one of the most specialised disciplines in the built environment.",
                  "Yet most hospitals in India are designed by general architects, built by general contractors, and coordinated by promoters left managing 15 different vendors on their own.",
                ].map((text, i) => (
                  <p key={i} style={{ color: "rgba(255,255,255,0.95)", lineHeight: 1.85, marginBottom: 18, fontSize: 16, fontWeight: 400, fontFamily: FONT }}>{text}</p>
                ))}

                <div style={{ borderLeft: `3px solid ${C.red}`, paddingLeft: 20, marginBottom: 32, marginTop: 28 }}>
                  <p style={{ color: "rgba(192,57,43,0.85)", lineHeight: 1.8, fontStyle: "italic", margin: 0, fontSize: 16, fontWeight: 400, fontFamily: FONT }}>
                    Facilities that fail NABH audits. Departments that don't function as clinicians need. Projects that run over budget and time.
                  </p>
                </div>

                <div style={{ display: "flex", alignItems: "center", gap: 16, padding: "18px 20px", background: "rgba(75,204,212,0.06)", border: "1px solid rgba(75,204,212,0.15)" }}>
                  <MedicalCross size={22} color={C.teal} opacity={0.7} />
                  <p style={{ color: C.teal, fontStyle: "italic", fontSize: 16, margin: 0, opacity: 0.85, fontWeight: 400, fontFamily: FONT }}>ARCHORA was founded to change that.</p>
                </div>
              </motion.div>

              {/* Blueprint illustration */}
              <motion.div
                initial={{ opacity: 0, x: 60 }} whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              >
                <div style={{ position: "relative", border: `1px solid rgba(75,204,212,0.15)`, padding: 24, background: "rgba(75,204,212,0.02)" }}>
                  <div style={{ position: "absolute", top: -1, left: -1, width: 40, height: 40, borderLeft: `2px solid ${C.teal}`, borderTop: `2px solid ${C.teal}`, opacity: 0.5 }} />
                  <div style={{ position: "absolute", bottom: -1, right: -1, width: 40, height: 40, borderRight: `2px solid ${C.teal}`, borderBottom: `2px solid ${C.teal}`, opacity: 0.5 }} />
                  <img
  src="/images/hero/problem-we-solve.jpg"
  alt="Healthcare infrastructure project by ARCHORA"
  style={{
    width: "100%",
    height: "520px",
    objectFit: "cover",
    borderRadius: "2px",
    display: "block",
  }}
  loading="lazy"
/>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            WHO WE ARE
        ══════════════════════════════════════════ */}
        <section aria-labelledby="whoweare-heading" style={{ background: C.cream, padding: "80px 0", position: "relative", overflow: "hidden" }}>
          <div className="home-wrap">
            <div className="home-split-2">
              <motion.div
                initial={{ opacity: 0, x: -60 }} whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              >
                <SectionLabel text="Who We Are" />
                <h2 id="whoweare-heading" style={{ color: C.navy, fontSize: "clamp(1.9rem, 5vw, 3.4rem)", lineHeight: 1.18, marginBottom: 24, fontWeight: 400, fontFamily: FONT }}>
                  A Team That Works Exclusively in Healthcare Infrastructure
                </h2>
                <p style={{ color: "#111111", lineHeight: 1.85, marginBottom: 18, fontSize: 16, fontWeight: 400, fontFamily: FONT }}>
                  ARCHORA is not a general architecture or construction firm that also takes healthcare projects. Every architect, every engineer, and every project manager works exclusively on healthcare facilities.
                </p>
                <p style={{ color: "#111111", lineHeight: 1.85, marginBottom: 32, fontSize: 16, fontWeight: 400, fontFamily: FONT }}>
                  This focus means we understand the compliance standards, the clinical workflows, the infection control requirements, and the operational realities that make healthcare infrastructure different from every other building type.
                </p>

                <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", background: C.navy, marginBottom: 36 }}>
                  <div style={{ width: 2, height: 36, background: C.teal, flexShrink: 0 }} />
                  <p style={{ color: C.teal, fontSize: 16, fontStyle: "italic", margin: 0, opacity: 0.9, lineHeight: 1.5, fontWeight: 400, fontFamily: FONT }}>
                    One team. One point of accountability. From concept to commissioning.
                  </p>
                </div>

                <div className="home-stat-3">
                  {[["20+", "Years Collective Experience"], ["Global", "Delivery"], ["NHS-Level", "UK Expertise"]].map(([val, lbl]) => (
                    <div key={lbl} style={{ borderTop: `2px solid ${C.blue}`, paddingTop: 14 }}>
                      <div style={{ fontSize: 22, color: C.navy, fontFamily: FONT, marginBottom: 6, lineHeight: 1, fontWeight: 400 }}>{val}</div>
                      <p style={{ fontSize: 12.5, color: "#1a1a1a", textTransform: "uppercase", letterSpacing: "0.12em", lineHeight: 1.5, margin: 0, fontWeight: 400, fontFamily: FONT }}>{lbl}</p>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                className="home-about-frame"
                initial={{ opacity: 0, x: 60 }} whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }} transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              >
                <div className="home-about-offset-border" />
                <div style={{ position: "relative", overflow: "hidden" }}>
                  <img
                    src="/images/about/team-at-work.jpg"
                    alt="ARCHORA healthcare infrastructure team at work"
                    className="home-about-img"
                    loading="lazy"
                  />
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(4,28,46,0.4) 0%, transparent 60%)" }} />
                </div>
                {[
                  { top: -1, left: -1, borderLeft: `2px solid ${C.blue}`, borderTop: `2px solid ${C.blue}` },
                  { bottom: -1, right: -1, borderRight: `2px solid ${C.blue}`, borderBottom: `2px solid ${C.blue}` },
                ].map((style, i) => (
                  <div key={i} style={{ position: "absolute", width: 44, height: 44, ...style }} />
                ))}
                <div style={{ position: "absolute", bottom: 16, left: 16, background: C.navy, padding: "10px 16px", borderLeft: `3px solid ${C.red}`, maxWidth: "calc(100% - 32px)" }}>
                  <p style={{ color: C.white, fontSize: 15, margin: 0, fontFamily: FONT, fontWeight: 400 }}>Healthcare Only. Always.</p>
                  <p style={{ color: "rgba(255,255,255,0.90)", fontSize: 12, margin: "4px 0 0", fontFamily: FONT, letterSpacing: "0.08em", fontWeight: 400 }}>Nothing outside infrastructure.</p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            METRICS STRIP
        ══════════════════════════════════════════ */}
        <div style={{ background: C.blue, padding: "48px 0", position: "relative", overflow: "hidden" }}>
          <div className="home-wrap home-metrics-grid">
            {metrics.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ duration: 0.6, delay: i * 0.1 }}
                className={`home-metric-cell${i < 3 ? " has-border" : ""}`}
              >
                <div style={{ fontSize: 40, color: C.white, fontFamily: FONT, lineHeight: 1, marginBottom: 8, fontWeight: 400 }}>
                  <AnimatedCounter to={m.val} suffix={m.suffix} />
                </div>
                <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 12.5, textTransform: "uppercase", letterSpacing: "0.16em", lineHeight: 1.5, margin: 0, fontFamily: FONT, fontWeight: 400 }}>
                  {m.label}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* ══════════════════════════════════════════
            SERVICES
        ══════════════════════════════════════════ */}
        <section aria-labelledby="services-heading" style={{ background: "#0a1628", padding: "80px 0", position: "relative", overflow: "hidden" }}>
          <div className="home-wrap">
            <motion.div style={{ marginBottom: 56, textAlign: "center" }} {...fadeUp}>
              <SectionLabel text="What We Do" light />
              <h2 id="services-heading" style={{ color: C.white, fontSize: "clamp(1.9rem, 5vw, 3.4rem)", fontWeight: 400, fontFamily: FONT, margin: "0 auto 16px" }}>
                Everything You Need to Design, Build & Deliver
              </h2>
              <p style={{ color: "rgba(255,255,255,0.90)", maxWidth: 520, margin: "0 auto", lineHeight: 1.75, fontSize: 16, fontWeight: 400, fontFamily: FONT }}>
                ARCHORA provides the complete range of healthcare infrastructure services under one roof.
              </p>
            </motion.div>

            <div className="home-services-grid">
              {services.map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-40px" }}
                  transition={{ duration: 0.5, delay: (i % 2) * 0.08 }}
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(s.slug ? `/services/${s.slug}` : "/services")}
                  onKeyDown={e => { if (e.key === "Enter" || e.key === " ") navigate(s.slug ? `/services/${s.slug}` : "/services"); }}
                  style={{ background: "#0a1628", padding: "28px 24px", cursor: "pointer", transition: "background 0.35s", position: "relative", overflow: "hidden" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = "#0d1f38"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = "#0a1628"; }}
                >
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 18 }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, minWidth: 28, paddingTop: 2 }}>
                      <span style={{ color: "rgba(75,204,212,0.35)", fontSize: 13, fontFamily: FONT, letterSpacing: "0.05em" }}>{s.num}</span>
                      <div style={{ width: 1, height: 32, background: "rgba(75,204,212,0.15)" }} />
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <h3 style={{ color: C.white, fontSize: 22, marginBottom: 12, fontFamily: FONT, fontWeight: 700, lineHeight: 1.3 }}>{s.title}</h3>
                      <p style={{ color: "rgba(255,255,255,0.92)", fontSize: 16, lineHeight: 1.75, margin: 0, fontWeight: 400, fontFamily: FONT }}>{s.desc}</p>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: C.teal, fontSize: 13, marginTop: 16, letterSpacing: "0.16em", fontFamily: FONT, opacity: 0.75 }}>
                        Learn More <span>→</span>
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            FINAL CTA
        ══════════════════════════════════════════ */}
        <section aria-labelledby="cta-heading" style={{ background: "#060f1e", padding: "96px 0", position: "relative", overflow: "hidden" }}>
          {[800, 600, 420, 280].map((size, i) => (
            <div
              key={size}
              aria-hidden="true"
              style={{
                position: "absolute", top: "50%", left: "50%",
                width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2,
                borderRadius: "50%", border: `1px solid rgba(75,204,212,${0.02 + i * 0.01})`, pointerEvents: "none", willChange: "transform",
                animation: `${i % 2 === 0 ? "spinCW" : "spinCCW"} ${60 + i * 20}s linear infinite`,
              }}
            />
          ))}

          <div className="home-wrap" style={{ maxWidth: 800, textAlign: "center", position: "relative", zIndex: 10 }}>
            <motion.div {...fadeUp}>
              <SectionLabel text="Get In Touch" light />

              <h2 id="cta-heading" style={{ color: C.white, fontSize: "clamp(2rem, 7vw, 4.2rem)", marginBottom: 24, fontWeight: 400, lineHeight: 1.15, fontFamily: FONT }}>
                Planning a Healthcare Facility?<br />
                <em style={{ color: C.teal, fontStyle: "italic" }}>Let's Talk.</em>
              </h2>

              <p style={{ color: "rgba(255,255,255,0.42)", marginBottom: 44, lineHeight: 1.85, maxWidth: 520, margin: "0 auto 44px", fontSize: 16, fontWeight: 400, fontFamily: FONT }}>
                Whether you are starting from zero or need expert support at any stage, ARCHORA is ready to help you design, build, and deliver infrastructure that works.
              </p>

              <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
                <HeroBtn primary onClick={() => navigate("/contact")}>Book a Free Consultation</HeroBtn>
                <HeroBtn onClick={() => window.open(WHATSAPP_URL, "_blank")}>WhatsApp Us</HeroBtn>
                <HeroBtn onClick={() => navigate("/contact")}>Send an Enquiry →</HeroBtn>
              </div>

              <p style={{ color: "rgba(255,255,255,0.2)", marginTop: 24, fontSize: 13, fontFamily: FONT, letterSpacing: "0.08em", fontWeight: 400 }}>
                No obligation · No sales pressure · Honest advice from healthcare infrastructure specialists
              </p>
            </motion.div>
          </div>
        </section>

      </div>
    </>
  );
}

// ─────────────────────────────────────────────
// SUB-COMPONENTS
// ─────────────────────────────────────────────
function HeroBtn({ children, primary, style: extraStyle, onClick }: { children: React.ReactNode; primary?: boolean; style?: React.CSSProperties; onClick?: () => void }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        padding: "13px 26px", fontSize: 13, letterSpacing: "0.16em",
        textTransform: "uppercase", cursor: "pointer", fontFamily: FONT,
        border: "none", transition: "all 0.25s ease",
        ...(primary ? {
          background: hover ? "#4bccd4" : "#1b6ca8",
          color: hover ? "#041c2e" : "#ffffff",
        } : {
          background: hover ? "rgba(255,255,255,0.12)" : "transparent",
          color: "#ffffff",
          border: "1px solid rgba(255,255,255,0.35)",
        }),
        ...extraStyle,
      }}
    >
      {children}
    </button>
  );
}

function NavBtn({ onClick, children, "aria-label": ariaLabel }: { onClick: () => void; children: React.ReactNode; "aria-label"?: string }) {
  return (
    <button
      onClick={onClick}
      aria-label={ariaLabel}
      style={{
        width: 36, height: 36, border: "1px solid rgba(255,255,255,0.2)",
        background: "transparent", color: "rgba(255,255,255,0.55)",
        cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
        backdropFilter: "blur(4px)", fontSize: 20, transition: "all 0.2s", flexShrink: 0,
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(75,204,212,0.5)"; (e.currentTarget as HTMLButtonElement).style.color = "#4bccd4"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.2)"; (e.currentTarget as HTMLButtonElement).style.color = "rgba(255,255,255,0.55)"; }}
    >
      {children}
    </button>
  );
}